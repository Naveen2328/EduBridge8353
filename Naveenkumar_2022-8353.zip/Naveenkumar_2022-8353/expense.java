package online;
import java.util.Scanner;
public class expense {
    public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner=new Scanner(System.in);
		double quantity,price,amount,discount;
		System.out.println("Enter the quantity of the product:");
		quantity=scanner.nextDouble();
		System.out.println("Enter the price of the product:");
		price=scanner.nextDouble();
		amount=quantity*price;
		if (amount>=5000)
		{
		discount=amount*0.1;
		amount=amount-discount;
		System.out.println("The total price of the product:" +amount);
		}

	}

}
