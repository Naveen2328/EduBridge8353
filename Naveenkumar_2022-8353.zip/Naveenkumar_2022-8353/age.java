package online;
import java.util.Scanner;
public class age {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter the ram age:");
		int ramAge=scanner.nextInt();
		System.out.println("Enter the sulabh age:");
		int sulabhAge=scanner.nextInt();
		System.out.println("Enter the ajay age:");
		int ajayAge=scanner.nextInt();
		
		if((ramAge<sulabhAge)&&(ramAge<ajayAge))
		{
			System.out.println("ram is young");
		}
		else if ((sulabhAge<ramAge)&&(sulabhAge<ajayAge))
		{
			System.out.println("sulabh is young");
		}
		else
		{
			System.out.println("ajay is young");
		}
	}

}
