package online;
import java.util.Scanner;
public class salary {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter the Salary amount:");
		int salary=scanner.nextInt();
		float hra,da,grossSalary;
		if(salary<1500)
		{
			hra=salary/10;
			da=salary*90/100;
			grossSalary=salary+hra+da;
			System.out.println("hra:" +hra);
			System.out.println("da:" +da);
			System.out.println("GrossSalary is:" +grossSalary);
		}
		else if(salary>=1500)
		{
			hra=500;
			da=salary*98/100;
			grossSalary=salary+hra+da;
			System.out.println("hra:" +hra);
			System.out.println("da:" +da);
			System.out.println("GrossSalary is:" +grossSalary);
		}
	}
}
