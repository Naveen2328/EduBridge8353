package online;
import java.util.Scanner;
public class subjects {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int eng,tam,maths,sci,soc;
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter the marks of 5 subjects : ");
		System.out.println("English : ");
		eng=scanner.nextInt();
		System.out.println("Tamil : ");
		tam=scanner.nextInt();
		System.out.println("Maths : ");
		maths=scanner.nextInt();
		System.out.println("Science : ");
		sci=scanner.nextInt();
		System.out.println("Social : ");
		soc=scanner.nextInt();
		int total=eng+tam+maths+sci+soc;
		float percentage=total/5;
		System.out.println("percentage Scored :" +percentage);
		if((percentage>=60)&&(percentage<=100))
		{
			System.out.println("First division");
		}
		else if((percentage>=50)&&(percentage<=59))
		{
			System.out.println("Second division");
		}
		else if((percentage>=40)&&(percentage<=49))
		{
			System.out.println("Third division");
		}
		else if((percentage>=0)&&(percentage<40))
		{
			System.out.println("Fail");
		}
		else
		{
			System.out.println("Invaild Input");
		} 
	}
}
