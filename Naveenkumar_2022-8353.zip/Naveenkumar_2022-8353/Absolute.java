package online;
import java.util.Scanner;
public class Absolute {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in); 
		  System.out.print("Enter a number: ");
		  int num = scanner.nextInt();
		  if(num<0)
		  {
			  int abs=-num;
		  System.out.println("The Absolute value "+num+" is"  +num );
		  }
		  else
		  {
			  System.out.println("The Absolute value "+num+" is"  +num);  
		  }
	}

}
