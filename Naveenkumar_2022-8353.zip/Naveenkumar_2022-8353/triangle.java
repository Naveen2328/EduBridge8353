package online;
import java.util.Scanner;
public class triangle {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter the angle_1 :");
		int angle1=scanner.nextInt();
		System.out.println("Enter the angle_2 :");
		int angle2=scanner.nextInt();
		System.out.println("Enter the angle_3 :");
		int angle3=scanner.nextInt();
		if(angle1+angle2+angle3==180)
		{
			System.out.println("Triangle is valid");
		}
		else
		{
			System.out.println("Triangle is not valid");
		}
	}

}
