package online;
import java.util.Scanner;
public class profit {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
         Scanner scanner= new Scanner(System.in);
         System.out.println("Enter the cost price:");
         int costPrice= scanner.nextInt();
         System.out.println("Enter the selling price:");
         int sellingPrice = scanner.nextInt();
         int profit,loss;
         if(sellingPrice>costPrice)
         {
        	 profit=sellingPrice-costPrice;
        	 System.out.println("Profit is" +profit);
         }
         else if(sellingPrice<costPrice)
         {
        	 loss=costPrice-sellingPrice;
        	 System.out.println("Loss is" +loss);
         }
	}

}
